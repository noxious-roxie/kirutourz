export default async function handler(req, res) {
  try {
    const url = req.query.url || req.body?.url;
    if (!url) return res.status(400).json({ error: "Missing URL" });

    // Node fetch available in Vercel
    const resp = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0' } });
    if (!resp.ok) return res.status(resp.status).json({ error: 'Failed to fetch URL' });

    const html = await resp.text();
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.status(200).json({ html });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
